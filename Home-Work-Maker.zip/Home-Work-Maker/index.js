const readline = require('readline-sync')
const algorithmia = require('algorithmia')

const wikiSearch = require('./wiki-search')
const textDecoration = require('./text-decoration')

const content = {}

content.searchTerm = readline.question('O que deseja Pesquisar? ')
console.log('')
content.resumeOrComplete = readline.questionInt('RESUMO [1] ..... COMPLETO [2] ')
console.log('')


wikiSearch.search(content.searchTerm,content.resumeOrComplete)

