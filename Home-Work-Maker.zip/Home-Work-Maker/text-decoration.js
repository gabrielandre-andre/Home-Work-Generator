function ok(){
    
}

module.exports = ok;