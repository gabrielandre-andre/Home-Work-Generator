const algorithmia = require('algorithmia')

const wikipedia = {}


async function searchTerm(term,term2){

    const input = {
        'articleName':term,
        'lang': 'pt'
    }
    
    wikipedia.client = algorithmia.client("YOUR API KEY")
    wikipedia.algo = wikipedia.client.algo("web/WikipediaParser/0.1.2") // timeout is optional
    wikipedia.pipe = await wikipedia.algo.pipe(input)
    wikipedia.get = wikipedia.pipe.get()
    
    wikipedia.content = wikipedia.get.content
    wikipedia.summary = wikipedia.get.summary



        function resumeOrComplete(){
            
            if(term2 == 1){

                console.log('')

                console.log(wikipedia.summary)

                console.log('')


            }else if(term2 == 2){

                console.log('')

                console.log(wikipedia.content)

                console.log('')

            
            }else{

                console.log('')

                console.log("Número Apertado Inválido!")

                console.log('')

            }

        }


        resumeOrComplete()




}













module.exports = {
    search : searchTerm
}